package com.hsm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hsm.entity.Appointment;


public interface AppointmentRepository extends JpaRepository<Appointment, Long>{
List<Appointment> findByDoctorId(long doctorId);

@Query(value="select count(*) as totalNoAppointments from appointment where doctor_id = ?1 ", nativeQuery = true)
int findCountOfAppointmentByDoctorId(long doctor_id);

@Query(value="select count(*) as totalNoAppointments from appointment where admin_id = ?1 ", nativeQuery = true)
int findCountOfAllAppointmentById(long admin_id);
}

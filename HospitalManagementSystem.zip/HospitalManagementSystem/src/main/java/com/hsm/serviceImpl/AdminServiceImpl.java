package com.hsm.serviceImpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsm.entity.Admin;
import com.hsm.repository.AdminRepository;
import com.hsm.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminRepository adminRepository;

   
	@Override
	public Admin getAdminById(Long id) {
		// TODO Auto-generated method stub
		return adminRepository.findById(id).orElse(null);
	}

	@Override
	public Admin createAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public Admin updateAdmin(Long id, Admin updatedAdmin) {
		// TODO Auto-generated method stub
		Admin existingAdmin = adminRepository.findById(id).orElse(null);
        if (existingAdmin == null) {
            return null; // Handle not found case
        }

        existingAdmin.setUserName(updatedAdmin.getUserName());
        existingAdmin.setPassword(updatedAdmin.getPassword());

        return adminRepository.save(existingAdmin);
    }

	@Override
	public boolean deleteAdmin(Long id) {
		// TODO Auto-generated method stub
		if (adminRepository.existsById(id)) {
            adminRepository.deleteById(id);
            return true;
        }
        return false; // Handle not found case
    }

	@Override
	public List<Admin> getAllAdmins() {
	    // Retrieve all Admins from the repository
	    return adminRepository.findAll();
	}

	@Override
	public Admin findAdminByUserNameAndPassword(Admin admin) {
		// TODO Auto-generated method stub
		System.out.println("inside admin service");
		return adminRepository.findByUserNameAndPassword(admin.getUserName(), admin.getPassword());
		
	}

}


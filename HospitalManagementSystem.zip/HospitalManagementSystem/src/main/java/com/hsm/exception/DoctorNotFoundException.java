package com.hsm.exception;

public class DoctorNotFoundException extends RuntimeException{

	public DoctorNotFoundException() {
		super("Doctor not found");
	}

	public DoctorNotFoundException(String message) {
		super(message);
	}
	
}

package com.hsm.service;

import java.util.List;
import java.util.Optional;

import com.hsm.entity.Appointment;

public interface AppointmentService {

	List<Appointment> getAllAppointments();

	Optional<Appointment> getAppointmentById(Long id);

	Appointment createAppointment(Appointment appointment, long doctorId);

	Appointment updateAppointment(Long id, Appointment updatedAppointment);

	boolean deleteAppointment(Long id);

	List<Appointment> getAppointmentByDoctorId(long doctorId);

	Appointment createAppointment(Appointment appointment);

	int countOfAppointmentByDoctorId(long doctor_id);
	
	
	int countOfAllAppointmentById(long admin_id);

	

}

package com.hsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import com.hsm.entity.Patient;
import com.hsm.exception.ResourceNotFoundException;
import com.hsm.service.PatientService;

@RestController
//@CrossOrigin(origins="*",allowedHeaders="*")
@CrossOrigin("*")
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientService patientService;

    
    //list of all patient
    @GetMapping("/patientlist")
    public List<Patient> getPatients() {
        return patientService.getPatient();
    }

    //retrieve patient by id
    @GetMapping("/{id}")
    public Patient getPatientById(@PathVariable(value = "id") long id) {
        return patientService.getPatientById(id);
    }
    

    //add patient
    @PostMapping("/add")
    @ResponseStatus(HttpStatus.CREATED)
    public void addPatient(@Validated @RequestBody Patient patient) {
        patientService.addPatient(patient);
    }
    
    

    //update 
//    @PutMapping("/patientlist/{mobileNo}")
//    public void updatePatient(@PathVariable long id, @RequestBody Patient patient) {
//        // Ensure the patient ID matches the path variable ID
//        patient.setPatientId(id);
//        patientService.updatePatient(patient);
//    }
    
    
  //Update patient details
    @PutMapping("/update/{id}")
    public ResponseEntity<String> updatePatient(@PathVariable(value = "id") long id, @Validated @RequestBody Patient updatedPatient) {
        Patient existingPatient = patientService.getPatientById(id);

        // Update the existing patient with the new details
        existingPatient.setFullName(updatedPatient.getFullName());
        existingPatient.setEmailId(updatedPatient.getEmailId());
        existingPatient.setMobileNo(updatedPatient.getMobileNo());
        existingPatient.setGender(updatedPatient.getGender());
        existingPatient.setAge(updatedPatient.getAge());
        existingPatient.setPassword(updatedPatient.getPassword());
        existingPatient.setPatientType(updatedPatient.getPatientType());
        existingPatient.setDoctType(updatedPatient.getDoctType());

        patientService.updatePatient(existingPatient);

        return new ResponseEntity<>("Patient updated successfully", HttpStatus.OK);
    }

    @DeleteMapping("/patientlist/{id}")
    public void deletePatient(@PathVariable long id) {
        patientService.deletePatient(id);
    }

    @PostMapping("/login")
    public Patient loginPatient(@Validated @RequestBody Patient patient) {
    	System.out.println("inside patient login" + patient);
        return patientService.findByEmailIdAndPassword(patient);
        
    }
    
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String handleResourceNotFoundException(ResourceNotFoundException ex) {
        return ex.getMessage();
    }
    
    
}

package com.hsm.controller;

import com.hsm.entity.Appointment;
import com.hsm.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/appointments")
@CrossOrigin("*")
public class AppointmentController {

    private final AppointmentService appointmentService;

    @Autowired
    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @GetMapping("/all")
    public List<Appointment> getAllAppointments() {
        return appointmentService.getAllAppointments();
    }

    @GetMapping("/{id}")
    public Optional<Appointment> getAppointmentById(@PathVariable Long id) {
        return appointmentService.getAppointmentById(id);
    }


    @PostMapping("/create/{doctorId}")
    public Appointment createAppointment(@RequestBody Appointment appointment, @PathVariable long doctorId) {
    	System.out.println(appointment);
        return appointmentService.createAppointment(appointment, doctorId);
    }
    
    @PostMapping("/create")
    public Appointment createAppointment(@RequestBody Appointment appointment) {
        return appointmentService.createAppointment(appointment);
    }

    @PutMapping("/update/{doctorid}")
    public Appointment updateAppointment(@RequestBody Appointment appointment,@PathVariable Long doctorid, 
    		@RequestBody Appointment updatedAppointment) {
        return appointmentService.updateAppointment(doctorid, updatedAppointment);
    }
    
    
    @PutMapping("/update/{id}")
    public Appointment updateAppointment(@PathVariable Long id, @RequestBody Appointment updatedAppointment) {
        return appointmentService.updateAppointment(id, updatedAppointment);
    }

    @DeleteMapping("/delete/{id}")
    public boolean deleteAppointment(@PathVariable Long id) {
        return appointmentService.deleteAppointment(id);
    }
    
    @GetMapping("/getByDoctorId/{doctorId}")
    public List<Appointment> getAppointmentByDoctorId(@PathVariable long doctorId) {
    	return appointmentService.getAppointmentByDoctorId(doctorId);
    }
    
    @GetMapping("/getCountByDoctorId/{doctorId}")
    public ResponseEntity<Integer> getTotalAppointmentsByDoctorId(@PathVariable long doctorId){
    	return new ResponseEntity<Integer>(appointmentService.countOfAppointmentByDoctorId(doctorId),HttpStatus.OK);
    }
    
    @GetMapping("/getCountAllAppointment/{adminId}")
    public ResponseEntity<Integer> getTotalAppointmentsById(@PathVariable long adminId){
    	return new ResponseEntity<Integer>(appointmentService.countOfAllAppointmentById(adminId),HttpStatus.OK);
    }
    
  
    
}
